import java.net.*;
import java.io.*;

public class Client
{
    
    //Constructor, builds a socket object
    public Client(String address, int port) throws IOException
    {
        try
        {
            // Set up socket
            socket = new Socket(address, port);
            System.out.println("Connected");
            
            // Set up data streams
            dataIn = new ObjectInputStream((socket.getInputStream()));
            dataOut = new DataOutputStream(socket.getOutputStream());
        }
        catch(UnknownHostException u)
        {
            System.out.println(u);
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
    }
    
    public static String[] getMovieTitles()
    {
        String outLine = "Show Movie Titles";
        
        // Tell Server the user wants the list of movie titles
        try 
        {
            dataOut.writeUTF(outLine);
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
        
        // Get list of movie titles from server and send it to GUI
        try
        {
            movieTitles = (String[]) dataIn.readObject();
            return movieTitles;
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
        catch(ClassNotFoundException o)
        {
            System.out.println();
        } 
                
        return null;
    }
    
    public static String[] getMovieTimes(String selectedMovie)
    {
        String movie = selectedMovie;
        
        // Tell Server what movie the user wants to see times for
        try 
        {
            dataOut.writeUTF(movie);
        }
        catch(IOException i)
        {
            System.out.println(i);
        }  
               
        // Get the list of movie times from the server and send it to the GUI
        try
        {
            movieTimes = (String[]) dataIn.readObject();
            return movieTimes;
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
        catch(ClassNotFoundException o)
        {
            System.out.println();
        }
                
        return null;
    }
    
    public static void closeClient()
    {
        // Tell the Server the user wants to exit
        try 
        {
            dataOut.writeUTF("Quit");
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
        
        // Pause to allow communication to server to finish
        try {
            Thread.sleep(100);
        }
        catch (InterruptedException ex){
        
        }

        // Close connections
        try
        {
            dataIn.close();
            dataOut.close();
            socket.close();
            System.out.println("Connection Closed");
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
    }
    
    public static void main(String args[]) throws IOException
    {
        
        movieGui movieGUIObj = new movieGui();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                movieGUIObj.setVisible(true);
                
            }
        });
        
        Client client = new Client("127.0.0.1", 5000);
    }
    
    // Variable declaration
    private static Socket socket = null;
    private static ObjectInputStream dataIn = null;
    private static DataOutputStream dataOut = null;
    private static String[] movieTitles;
    private static String[] movieTimes;
}

READ ME FOR MOVIE SHOWTIMES

Step One- Open up and run the server exe, do this by opening and running MovieShowTimesServer

Step Two- Open and run the client exe, this will be titled MovieShowTimesClient

A movie showtimes GUI application should pop up in a separate window at this point

Step Three- Click the "Show Movies" Button on the application to show a list of movies currently showing

Step Four- Scroll Through the list and double click on the movie you want times showing for

Step Five- Click the button that appears, then a list of movie showtimes will appear in a list to the right screen application

Step Six- If the times do not fit your schedule you can go back to the list and double click a different movie.
At that point repeat step five to get the showtimes for the newly selected movie.

At anytime the exit button can be hit, this will close the application and ping the server to shutdown as well

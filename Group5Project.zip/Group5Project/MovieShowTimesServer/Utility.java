import java.util.ArrayList;
import java.util.List;

public class Utility
{
    // Constructor
    public Utility()
    {
        // Create all Movies
        String[] bladerunnerTimes = {"12;00 PM", "1:30 PM", "3:00 PM", "4:30 PM", "6:00 PM"};
        addMovie("Blade Runner", bladerunnerTimes);

        String[] conjuringTimes = {"1:15 PM", "2:45 PM", "4:15 PM", "5:45 PM", "7:15 PM"};
        addMovie("The Conjuring", conjuringTimes);

        String[] princessTimes = {"11:00 AM", "2:00 PM", "3:30 PM", "5:00 PM", "6:30 PM"};
        addMovie("The Princess Bride", princessTimes);

        String[] soulTimes = {"10:30 AM", "12:00 PM", "1:30 PM", "3:00 PM", "4:30 PM"};
        addMovie("Soul", soulTimes);

        String[] upTimes = {"10:00 AM", "11:45 AM", "1:00 PM", "2:45 PM", "4:00 PM"};
        addMovie("Up", upTimes);
    }

    public static void addMovie (String movieTitle, String[] movieTimes)
    {
        // Create movie with given title and times and add to moviesList
        Movie m = new Movie(movieTitle, movieTimes);
        moviesList.add(m);
    }

    public String[] getRequestedTimes (String movieName)
    {
        // Search through list of movies
        for (Movie m : moviesList)
        {
            if (m.getName().equals(movieName)) // if requested movie is found
            {
                return m.getTimes(); // return list of times
            }
        }

        // If movie not found
        String[] empty = {"Movie Not Found"};
        return empty;
    }

    // Create list of movie titles
    public ArrayList<String> createMovieTitles()
    {
        for (Movie m : moviesList)
        {
            movieTitles.add(m.getName());
        }

        return movieTitles;
    }

    // Variable declaration
    private static ArrayList<Movie> moviesList = new ArrayList<Movie>();
    private ArrayList<String> movieTitles = new ArrayList<String>();
}

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server
{
    public Server(int port)
    {
        // Start server and wait for a connection
        try
        {
            // Set up socket
            serverSocket = new ServerSocket(port);
            System.out.println("Waiting for a client...");

            clientSocket = serverSocket.accept();
            System.out.println("Client accepted");

            // create DataInputStream so that data can be read
            dataIn = new DataInputStream(new BufferedInputStream(clientSocket.getInputStream()));
            // crete DataOutputStream so that data can be sent out
            dataOut = new ObjectOutputStream(clientSocket.getOutputStream());

            String inLine = "";
            boolean prevRequest = false;

            // Get initial request from client
            inLine = dataIn.readUTF();

            // Communicate until client sends "Quit"
            while (!inLine.equals("Quit"))
            {
                // If client sends "Show Movie Titles", send list of movies to client
                if(inLine.equals("Show Movie Titles"))
                {
                    // Create output (list of movies) as an array of strings
                    movieTitlesArray = util.createMovieTitles().toArray(new String[0]);

                    // Send list to client
                    dataOut.writeObject(movieTitlesArray);

                    // Get requested movie from client
                    requestedTitle = dataIn.readUTF();
                }

                if (prevRequest == true)
                {
                    // Client is requesting times for an additional movie
                    requestedTitle = inLine;
                }

                // Get list of times for requested movie as an array of strings
                requestedTimesArray = util.getRequestedTimes(requestedTitle);

                // Return list of times to client
                dataOut.writeObject(requestedTimesArray);

                prevRequest = true;

                // Check for next client request
                inLine = dataIn.readUTF();
            }

            // When user hits quit on client
            System.out.println("Closing Connection");
            // Close datastreams
            dataIn.close();
            dataOut.close();

            // Close socket
            //serverSocket.close();
            clientSocket.close();

            System.out.println("Connection Closed");
        }
        catch(IOException exception)
        {
            System.out.println(exception);
        }
    }


    public static void main(String args[])
    {
        Server server = new Server(5000);
    }


    // Variable declaration
    private Socket clientSocket = null;
    private ServerSocket serverSocket = null;
    private ObjectOutputStream dataOut = null;
    private DataInputStream dataIn = null;
    private String[] movieTitlesArray;
    private String requestedTitle = "";
    private String[] requestedTimesArray;
    private Utility util = new Utility();
}

import java.util.ArrayList;

public class Movie
{
    // Contructor, creates a Movie with a given title and list of times
    public Movie(String title, String[] times)
    {
        movieTitle = title;
        movieTimes = times;
    }

    public String getName()
    {
        return movieTitle;
    }

    public String[] getTimes()
    {
        return movieTimes;
    }

    // Variable declaration
    private String movieTitle;
    private String[] movieTimes;
}
